# images/

Place all your photo and video thumbnail files here.

## Naming Suggestions
- hero.jpg              ← Home page hero background
- xav-profile.jpg       ← About page profile photo
- gallery-001.jpg       ← Gallery photos (number them)
- gallery-002.jpg
- gallery-003.jpg
- ...

## Tips
- Keep each image under 1MB
- Use JPG for photos, PNG for logos
- Minimum 1200px wide for full-bleed images
- Square images (1:1) work best for gallery grid cells
